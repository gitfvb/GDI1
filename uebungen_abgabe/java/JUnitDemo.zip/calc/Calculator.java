package calc;

public class Calculator {
    private static int result;      // Statische Variable fuer Speicherung des Ergebnisses

    /**
     * add n to the current value
     * @param n the value to be added
     */
    public void add(int n) {
        result = result + n;
    }
    
    /**
     * subtract n from the current result
     * @param n the value to be substracted
     */
    public void substract(int n) {
        result = result - 1;        // Bug: should be result = result - n
    }
    
    /**
     * multiply current value by n, <em>not yet implemented</em>
     * @param n the value used for the multiplication
     */
    public void multiply(int n) {   // not yet implemented...
    }
    
    /**
     * (integer) divide result by n
     * @param n the value by which to divide the current value
     */
    public void divide(int n) {
        result = result / n;
    }
    
    /**
     * set result to the square value of value n
     * @param n the value to square
     */
    public void square(int n) {
        result = n * n;
    }
    
    /**
     * calculate the square root (as an int...)
     * @param n the number for which to calculate the square root
     */
    public void squareRoot(int n) {
        for (; ;) ;                 // Bug: infinite loop
    }
    
    /**
     * clears the calculator (value = 0)
     */
    public void clear() {           // Ergebnis loeschen auf 0
        result = 0;
    }
    
    /**
     * turns the calculator on
     */
    public void switchOn() {
        // Turn on display, show "Hello", beep, ...
        // Whatever such devices can do these days!
        result = 0;
    }
    
    /**
     * turns the calculator off
     */
    public void switchOff() {
        // Anzeigen �Tschuess", piepen, Display ausschalten
    }
    
    /**
     * returns the current value of the calculator
     * @return the current value stored in the calculator
     */
    public int getResult() {
        return result;
    }
}