import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GUITest extends JFrame {
  private JLabel infoLabel;
  public GUITest(String title) {
    super(title);

    // Now, also define that the [X] terminates the program correctly
     addWindowListener(new MyWindowListener());

    Container pane = getContentPane();
    pane.setLayout(new GridLayout(3, 1));
    infoLabel = new JLabel(
        "Press the [Exit] or [X] in the top right corner to exit");
    pane.add(infoLabel);

    // Create a new push button that may be used in addition to the [X]
    JButton button = new JButton("Exit");

    // Define that the program should exit if you click the button
    button.addActionListener(new ExitButtonListener());
    pane.add(button);
    // Create another button that changes the text of the Label
    button = new JButton("Change Label Text");
    // Now, define what should happen if the button is pressed
    button.addActionListener(new ChangeButtonListener());
    pane.add(button);
  }
  private class ChangeButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      infoLabel.setText("You clicked the button! Now [Exit] or [X]");
    }
  }
  // Exit the program when the window close button is clicked
  class MyWindowListener extends WindowAdapter {
    public void windowClosing(WindowEvent e) {
      System.exit(0);
    }
  }
  // Exit the program when the �Exit�-button is clicked
  class ExitButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      System.exit(0);
    }
  }
  public static void main(String args[]) {
    GUITest theWindow = new GUITest("My first GUI Application");
    theWindow.setSize(WIDTH, HEIGHT);
    theWindow.setVisible(true);
  }
  public static final int WIDTH = 400;
  public static final int HEIGHT = 300;
}
