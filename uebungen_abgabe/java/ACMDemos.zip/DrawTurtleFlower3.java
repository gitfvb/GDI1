/*
 * File: DrawTurtleFlower3.java
 * ----------------------------
 * This program draws a turtle flower using a GTurtle subclass
 * that knows how to draw flowers.
 */

import acm.graphics.*;
import acm.program.*;

public class DrawTurtleFlower3 extends GraphicsProgram {

/**
 * Runs the program.  This program creates a FlowerTurtle object,
 * centers it in the screen, and then asks it to draw a flower.
 */
	public void run() {
		FlowerTurtle turtle = new FlowerTurtle();
		add(turtle, getWidth() / 2, getHeight() / 2);
		turtle.penDown();
		turtle.drawFlower();
	}
}

/**
 * A GTurtle subclass that knows how to draw a flower.
 */

class FlowerTurtle extends GTurtle {

/** Draws a flower with 36 squares separated by 10-degree turns. */
	public void drawFlower() {
		for (int i = 0; i < 36; i++) {
			drawSquare();
			left(10);
		}
	}

/** Draws a square with four lines separated by 90-degree turns. */
	private void drawSquare() {
		for (int i = 0; i < 4; i++) {
			forward(100);
			left(90);
		}
	}
}
