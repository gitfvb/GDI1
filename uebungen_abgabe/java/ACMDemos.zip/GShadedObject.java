import java.awt.Color;
import java.awt.Graphics;

import acm.graphics.GObject;
import acm.graphics.GRoundRect;

public abstract class GShadedObject extends GObject {

	private GRoundRect rect;
	
	public GShadedObject(double x, double y, double w, double h) {
		rect = new GRoundRect(getLocation().getX()+5, getLocation().getY()+5,
				getWidth(), getHeight());
		rect.setFilled(true);
		rect.setFillColor(Color.GRAY);
	}
	
	@Override
	public void paint(Graphics g) {
		if (rect == null) {
			
			rect = new GRoundRect(getLocation().getX(), getLocation().getY(),
					getWidth(), getHeight());
			rect.setFilled(true);
			rect.setFillColor(Color.GRAY);
		}
		rect.paint(g);
	}
}
