/*
 * File: CurrencyTable.java
 * ------------------------
 * This file provides a stub implementation of the CurrencyTable
 * class used by the CurrencyConverter example.  This implementation
 * simply returns a set of data values stored statically in the
 * class.  A more ambitious implementation could go out to the web
 * and retrieve the actual data.
 */

import acm.util.*;

/** This class implements a currency table */
public class CurrencyTable {

/** Return an array containing the names of all defined currencies */
	public String[] getCurrencyNames() {
		int nCurrencies = CURRENCIES.length;
		String[] names = new String[nCurrencies];
		for (int i = 0; i < nCurrencies; i++) {
			names[i] = CURRENCIES[i].getName();
		}
		return names;
	}

/** Return the exchange rate for a named currency */
	public double getExchangeRate(String name) {
		for (int i = 0; i < CURRENCIES.length; i++) {
			if (name.equalsIgnoreCase(CURRENCIES[i].getName())) {
				return CURRENCIES[i].getRate();
			}
		}
		throw new ErrorException("No currency named " + name);
	}

/** Return the date at which the exchange rate is calculated */
	public String getDate() {
		return TABLE_DATE;
	}

/* Currency table (Source: Interbank Rate for 22-Jul-05) */
	private static final String TABLE_DATE = "22-Jul-05";
	private static final CurrencyEntry[] CURRENCIES = {
		new CurrencyEntry("Australian Dollar", 0.766),
		new CurrencyEntry("Brazilian Real", 0.435),
		new CurrencyEntry("British Pound", 1.754),
		new CurrencyEntry("Canadian Dollar", 0.821),
		new CurrencyEntry("Chinese Yuan", 0.121),
		new CurrencyEntry("Euro", 1.218),
		new CurrencyEntry("Japanese Yen", 0.00908),
		new CurrencyEntry("Mexican Peso", 0.942),
		new CurrencyEntry("South African Rand", 0.153),
		new CurrencyEntry("Swiss Franc", 0.779),
		new CurrencyEntry("US Dollar", 1.000)
	};
}

/* Package class: CurrencyEntry */
/**
 * This class is used to store the name of a currency together with
 * its relative value in comparison to the other currencies.  The
 * example defines the dollar as 1.0, but the code does not depend
 * on that definition.
 */

class CurrencyEntry {

	public CurrencyEntry(String name, double rate) {
		currencyName = name;
		exchangeRate = rate;
	}

	public String getName() {
		return currencyName;
	}

	public double getRate() {
		return exchangeRate;
	}

	private String currencyName;
	private double exchangeRate;

}
