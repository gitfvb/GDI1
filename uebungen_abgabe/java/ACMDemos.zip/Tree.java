
public class Tree {
	public static void main(String[] args) {
		int height = 5;			// <- hier �ndern, um gr��e zu variieren... alles
    if (args.length > 0) {
      try {
        int val = Integer.valueOf(args[0]);
        System.err.println("val: " + val);
        height = val;
      } catch (NumberFormatException nfe) {
        System.err.println("Invocation: java Tree n"
            +"\n  where n is the tree's width as an int");
      }
    }
		int width = height+1;
		Empty air = new Empty();
		Leafs green = new Leafs();
		Trunk brown = new Trunk();
		
		int i=0;
		
		System.out.print(air.show(width));
		System.out.println("|");
		System.out.print(air.show(width-1));
		System.out.println("-+-");
		
		while (height >=0){
			System.out.print(air.show(width-i));
			System.out.println(green.show((i*2)+1));
			i++;
			height--;
		}
		
		for (i = 0; i<=1; i++){
			System.out.print(air.show(width-1));
			System.out.println(brown.show());
		}
	}
}
