/*
 * Created on 19.09.2007 by Guido Roessling <roessling@acm.org>
 */

public class SelSort {
  public void selection(int[] f, int n) {
  int i, j, m, hilf;
  for (i=n-1; i>0; i--) {
    m = 0;
    for (j=1; j<=i; j++)
      if (f[j] > f[m])
        m = j;
    hilf = f[i];
    f[i] = f[m];
    f[m] = hilf;
  }
  }
    
  public void printArray(int[] array) {
    for (int i=0; i<array.length; i++)
      System.out.print(array[i] +" ");
    System.out.println("...");
  }
  
  public static void main(String[] args) {
    SelSort demo = new SelSort();
    int[] array = new int[] {4, 3, 2, 1};
    demo.printArray(array);
    demo.selection(array, 4);
    demo.printArray(array);
  }
}
