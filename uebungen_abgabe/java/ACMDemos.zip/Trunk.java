
public class Trunk extends Leafs{
	
	 Trunk () {
		 look = "| |";
	 }
	 
	 String show(){
			return look;
	 }

}