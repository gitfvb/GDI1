/*
 * File: FeltBoard.java
 * --------------------
 * This program offers a simple example of the acm.graphics package
 * that draws a red rectangle and a green oval.  The dimensions of
 * the rectangle are chosen so that its sides are in proportion to
 * the "golden ratio" thought by the Greeks to represent the most
 * aesthetically pleasing geometry.
 */

import java.awt.Color;

import acm.graphics.GRect;
import acm.graphics.GSquare2;
import acm.graphics.GStrangeRect;
import acm.graphics.GStringArray;
import acm.graphics.GStringArrayCompound;
import acm.program.GraphicsProgram;

public class FeltBoard3 extends GraphicsProgram {

/** Runs the program */
	public void run() {
		GRect rect = new GRect(100, 50, 100, 100 / PHI);
		rect.setFilled(true);
		rect.setColor(Color.RED);
		add(rect);
		GSquare2 sq2 = new GSquare2(100,80, 80);
		sq2.setColor(Color.GREEN);
		add(sq2);
		GStrangeRect rect2 = new GStrangeRect(130, 80, 100, 100 / PHI);
		rect2.setFilled(true);
		rect2.setColor(Color.RED);
		add(rect2);
		String[] demo = new String[]{"Book2","Page9","Chapter 24.10","P3", "Word 17"};
//		GStringArray array1 = new GStringArray(demo, 200, 200);
//		add(array1);
		GStringArrayCompound array2 = new GStringArrayCompound(demo, 200, 300);
		array2.setColor(Color.black);
		array2.markAsComplete();
		add(array2);
		System.err.println(array2 +"\n "+array2.getElementCount() );
	}

/** Constant representing the golden ratio */
	public static final double PHI = 1.618;

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new FeltBoard3().start(args);
	}
}
