/*
 * File: DrawFace.java
 * -------------------
 * This program creates a GFace object.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.event.*;

public class DrawFace extends GraphicsProgram {

	public void run() {
		face = new GFace(FACE_WIDTH, FACE_HEIGHT);
		add(face, getWidth() / 2, getHeight() / 2);
		addMouseListeners();
	}

/** Called when the mouse is moved to adjust the eyes */
	public void mouseMoved(MouseEvent e) {
		face.lookAt(e.getX(), e.getY());
	}

/* Constants */
	private static final double FACE_WIDTH = 200;
	private static final double FACE_HEIGHT = 300;

/* Private instance variables */
	private GFace face;
	private GObject gobj;

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new DrawFace().start(args);
	}
}
