
public class Sphere extends Leafs{
	 private String tiny, big;
		
	 Sphere () {
		 tiny = "o";
		 big = "O";
	 }
	
	
	String show(int width){
		String row="";
		
		if (width >= 2){
			row += tiny+this.show(width -2)+tiny;
		}else if (width >= 1){
			row += big;
		}
		return row;
	}
	
}
