/*
 * File: Add2Program.java
 * ----------------------
 * This program adds two numbers and prints their sum.  Because
 * this version is a Program, input and output are assigned to
 * System.in and System.out.
 */

import acm.program.*;

public class Add2Program extends Program {
	public void run() {
		println("This program adds two numbers.");
		int n1 = readInt("Enter n1: ");
		int n2 = readInt("Enter n2: ");
		int total = n1 + n2;
		println("The total is " + total + ".");
	}

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new Add2Program().start(args);
	}
}

