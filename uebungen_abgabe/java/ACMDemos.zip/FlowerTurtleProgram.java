/*
 * File: FlowerTurtleProgram.java
 * ------------------------------
 * This program draws a turtle flower by invoking a GTurtle
 * object as if it were a program.
 */

import acm.graphics.*;

public class FlowerTurtleProgram extends GTurtle {

/** Runs the program. */
	public void run() {
		penDown();
		flower();
	}

/** Draws a flower with 36 squares separated by 10-degree turns. */
	private void flower() {
		for (int i = 0; i < 36; i++) {
			square();
			left(10);
		}
	}

/** Draws a square with four lines separated by 90-degree turns. */
	private void square() {
		for (int i = 0; i < 4; i++) {
			forward(100);
			left(90);
		}
	}
}

