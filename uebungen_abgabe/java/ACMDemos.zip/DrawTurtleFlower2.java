/*
 * File: DrawTurtleFlower2.java
 * ----------------------------
 * This program draws a turtle flower using receiver-relative
 * invocations and two levels of decomposition.
 */

import acm.graphics.*;
import acm.program.*;

public class DrawTurtleFlower2 extends GraphicsProgram {

/**
 * Runs the program.  This program creates a GTurtle object,
 * puts it in the center of the screen, and then draws a flower.
 */
	public void run() {
		turtle = new GTurtle();
		add(turtle, getWidth() / 2, getHeight() / 2);
		turtle.penDown();
		drawFlower();
	}

/** Draws a flower with 36 squares separated by 10-degree turns. */
	private void drawFlower() {
		for (int i = 0; i < 36; i++) {
			drawSquare();
			turtle.left(10);
		}
	}

/** Draws a square with four lines separated by 90-degree turns. */
	private void drawSquare() {
		for (int i = 0; i < 4; i++) {
			turtle.forward(100);
			turtle.left(90);
		}
	}

/** Holds the GTurtle object as an instance variable */
	private GTurtle turtle;

}


