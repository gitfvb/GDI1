/*
 * File: SimpleTableExample.java
 * -----------------------------
 * This program illustrates the basic arrangment of the
 * TableLayout mechanism by laying out six buttons in a
 * 2x3 grid.
 */

import acm.gui.*;
import acm.program.*;
import javax.swing.*;

/**
 * This class arranges six buttons in a table.
 */
public class SimpleTableExample extends Program {

/** Set the program dimensions */
	public static final int APPLICATION_WIDTH = 350;
	public static final int APPLICATION_HEIGHT = 200;

/** Initialize the display by adding a set of buttons */
	public void init() {
		setLayout(new TableLayout(2, 3));
		add(new JButton("A"));
		add(new JButton("B"));
		add(new JButton("C"));
		add(new JButton("D"));
		add(new JButton("E"));
		add(new JButton("F"));
	}

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new SimpleTableExample().start(args);
	}
}
