/*
 * File: DrawTurtleFlower1.java
 * ----------------------------
 * This program draws a turtle flower using receiver-relative
 * invocations in a single, undecomposed run method.
 */

import acm.graphics.*;
import acm.program.*;

public class DrawTurtleFlower1 extends GraphicsProgram {

/**
 * Runs the program.  This program creates a GTurtle object,
 * puts it in the center of the screen, and then draws a flower.
 * The flower consiste of 36 squares, with a 10-degrees rotation
 * between each one.  The squares, in turn, are drawn by drawing
 * four line segments interspersed with 90-degree rotations.
 */
	public void run() {
		GTurtle turtle = new GTurtle();
		add(turtle, getWidth() / 2, getHeight() / 2);
		turtle.penDown();
		for (int i = 0; i < 36; i++) {
			for (int j = 0; j < 4; j++) {
				turtle.forward(100);
				turtle.left(90);
			}
			turtle.left(10);
		}
	}
}

