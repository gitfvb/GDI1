/*
 * File: StoplightUsingInnerClasses.java
 * -------------------------------------
 * This program is identical to StoplightConsole except that the
 * listener is specified explicitly using an anonymous inner class.
 */

import acm.program.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This class displays three buttons at the south edge of the window.
 * The name of the button is echoed on the console each time a button
 * is pressed.
 */

public class StoplightUsingInnerClasses extends ConsoleProgram {

/** Initialize the GUI */
	public void init() {
		ActionListener listener = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				println(e.getActionCommand());
			}
		};
		JButton greenButton = new JButton("Green");
		JButton yellowButton = new JButton("Yellow");
		JButton redButton = new JButton("Red");
		greenButton.addActionListener(listener);
		yellowButton.addActionListener(listener);
		redButton.addActionListener(listener);
		add(greenButton, SOUTH);
		add(yellowButton, SOUTH);
		add(redButton, SOUTH);
	}

/** Set the program dimensions */
	public static final int APPLICATION_WIDTH = 350;
	public static final int APPLICATION_HEIGHT = 250;

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new StoplightUsingInnerClasses().start(args);
	}
}

