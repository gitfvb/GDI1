
public class Empty {

	 public String look;
		
	 Empty () {
		 look = " ";
	 }
	
	String show(int width){
		String row ="";
		for (int i=0;i<=width;i++)
			row += look;
		return row;
	}
}