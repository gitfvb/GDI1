
public class Leafs extends Empty{
	 Leafs () {
		 look = "*";
	 }
		
	 String show(int width){
		String row ="";
		Sphere blue = new Sphere(); 
		if (width>=5){
			int a = (width-3)/2;
			int b = width - 2*a;
			row += this.show(a)+blue.show(b)+this.show(a);
		}else if (width>=3){
			int a = (width-1)/2;
			int b = width - 2*a;
			row += this.show(a)+blue.show(b)+this.show(a);
	 	}else if (width>=1){
			row += look+this.show(width-1);
	 	}

		return row;
	}
}
