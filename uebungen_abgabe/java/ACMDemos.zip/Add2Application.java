/*
 * File: Add2Application.java
 * --------------------------
 * This program adds two numbers and prints their sum.  This version
 * runs as a Java application without using the acm.program package.
 */

import acm.io.*;
import java.awt.*;
import javax.swing.*;

public class Add2Application {
	public static void main(String[] argv) {
		JFrame frame = new JFrame("Add2Application");
		IOConsole console = new IOConsole();
		frame.getContentPane().add(BorderLayout.CENTER, console);
		frame.setSize(500, 300);
		frame.show();
		console.println("This program adds two numbers.");
		int n1 = console.readInt("Enter n1: ");
		int n2 = console.readInt("Enter n2: ");
		int total = n1 + n2;
		console.println("The total is " + total + ".");
	}
}
