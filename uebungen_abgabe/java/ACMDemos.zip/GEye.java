/*
 * File: GEye.java
 * ---------------
 * This file defines a GEye class that can look in a particular
 * direction.
 */

import acm.graphics.*;

public class GEye extends GCompound {

/** Creates a new instance of the GEye class */
	public GEye(double width, double height) {
		add(new GOval(width, height), -width / 2, -height / 2);
		r = PUPIL_RADIUS_FRACTION * Math.min(width, height);
		pupil = new GOval(2 * r, 2 * r);
		pupil.setFilled(true);
		add(pupil, -r, -r);
	}

/**
 * Shifts the eye to look at the point (x, y).  Note that x
 * and y are in the coordinate system of the canvas and not
 * in the local coordinate space of the compound.  The call
 * to getCanvasPoint returns the coordinate of the eye shifted
 * to the space of the canvas.
 */
	public void lookAt(double x, double y) {
		GPoint pt = getCanvasPoint(0, 0);
		pupil.setLocation(-r, -r);
		pupil.movePolar(r, GMath.angle(x - pt.getX(), y - pt.getY()));
	}

/* Pupil radius as a function of the eye size */
	private static final double PUPIL_RADIUS_FRACTION = 0.2;

/* Instance variables */
	private GOval pupil;
	private double r;
}
