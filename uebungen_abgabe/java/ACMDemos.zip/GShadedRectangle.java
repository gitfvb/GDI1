import java.awt.Color;
import java.awt.Graphics;

import acm.graphics.GRect;
import acm.graphics.GRectangle;


public class GShadedRectangle extends GShadedObject {

	GRect myRect;
	
	public GShadedRectangle(double x, double y, double w, double h) {
		super(x, y, w, h);
		myRect = new GRect(x, y, w, h);
		myRect.setFilled(true);
		myRect.setFillColor(Color.BLUE);
	}
	@Override
	public GRectangle getBounds() {
		return myRect.getBounds();
//		return new GRectangle(100, 100, 200, 200);
//		return new GRectangle(rect.getX(), rect.getY(), 
//				rect.getWidth()+5, rect.getHeight()+5);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		myRect.paint(g);
	}

}
