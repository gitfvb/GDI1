/*
 * File: ProgramLayoutDemo.java
 * ----------------------------
 * This program illustrates the ProgramLayout mechanism.
 */

import acm.program.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This class creates a self-documenting example of the proposed
 * ProgramLayout mechanism.  In this example, the center of the
 * window is occupied by an IOConsole, which is created by the
 * ConsoleProgram.  The constructor for this example adds several
 * JButtons to show how ProgramLayout organizes each region.
 */
public class ProgramLayoutDemo extends ConsoleProgram {

/** Set the program dimensions */
	public static final int APPLICATION_WIDTH = 600;
	public static final int APPLICATION_HEIGHT = 350;

/** Install the buttons for the program */
	public ProgramLayoutDemo() {
		add(new JButton("N1"), NORTH);
		add(new JButton("N2"), NORTH);
		add(new JButton("N3"), NORTH);
		add(new JButton("W1"), WEST);
		add(new JButton("W2"), WEST);
		add(new JButton("E1"), EAST);
		add(new JButton("E2"), EAST);
		add(new JButton("S1"), SOUTH);
		add(new JScrollBar(JScrollBar.HORIZONTAL), SOUTH, "fill=HORIZONTAL");
		add(new JButton("S2"), SOUTH);
		addActionListeners();
	}

/** Run the program */
	public void run() {
		println("This program is a simple test of the ProgramLayout");
		println("manager. The main class extends ConsoleProgram,");
		println("which means that an IOConsole is automatically added");
		println("to the CENTER component. The NORTH and SOUTH regions");
		println("use a TableLayout manager specifying a single row;");
		println("the WEST and EAST regions use a TableLayout manager");
		println("specifying a single column.  The SOUTH region includes");
		println("a JScrollBar along with the JButtons to show how the");
		println("layout manager automaticaly assigns more than the");
		println("minimum width, which would show an empty scrollbar.");
		println();
		println("Although this example shows interactors along all");
		println("four edges, students will typically add interactors");
		println("along only one edge.");
		println();
	}

/** Respond to action events */
	public void actionPerformed(ActionEvent e) {
		println("Button " + e.getActionCommand() + " pressed.");
	}

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new ProgramLayoutDemo().start(args);
	}
}
