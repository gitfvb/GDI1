/*
 * File: FeltBoard.java
 * --------------------
 * This program offers a simple example of the acm.graphics package
 * that draws a red rectangle and a green oval.  The dimensions of
 * the rectangle are chosen so that its sides are in proportion to
 * the "golden ratio" thought by the Greeks to represent the most
 * aesthetically pleasing geometry.
 */

import java.awt.Color;

import acm.graphics.GOval;
import acm.graphics.GRect;
import acm.graphics.GSquare;
import acm.program.GraphicsProgram;

public class FeltBoard2 extends GraphicsProgram {

/** Runs the program */
	public void run() {
		GRect rect = new GRect(100, 50, 100, 100 / PHI);
		rect.setFilled(true);
		rect.setColor(Color.RED);
		add(rect);
		GOval oval = new GOval(150, 50 + 50 / PHI, 100, 100 / PHI);
		oval.setFilled(true);
		oval.setColor(Color.GREEN);
		add(oval);
		GSquare square = new GSquare(120, 80, 60);
		square.setColor(Color.black);
		add(square);
		GShadedRectangle gsr = new GShadedRectangle(60,90,100,120);
		add(gsr);
	}

/** Constant representing the golden ratio */
	public static final double PHI = 1.618;

/* Standard Java entry point */
/* This method can be eliminated in most Java environments */
	public static void main(String[] args) {
		new FeltBoard2().start(args);
	}
}
